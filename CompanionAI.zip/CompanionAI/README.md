# Companion AI
An Android AI friend with a name, memory, mood, and approved self-upgrades.

## Get the APK
1. Upload all these files to a new GitHub repo (keep the .github folder).
2. Open the Actions tab -> "Build APK" -> wait ~5 minutes.
3. Open the finished run -> Artifacts -> download CompanionAI-apk, unzip, install app-debug.apk.

## First run
Tap Settings, enter your AI's name and your Anthropic API key (console.anthropic.com).
