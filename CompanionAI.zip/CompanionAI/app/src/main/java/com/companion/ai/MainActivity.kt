package com.companion.ai

import android.app.Activity
import android.app.AlertDialog
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : Activity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var chatBox: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private lateinit var sendBtn: Button
    private lateinit var moodView: TextView

    private fun aiName() = prefs.getString("name", "Luna") ?: "Luna"
    private fun apiKey() = prefs.getString("key", "") ?: ""
    private fun model() = prefs.getString("model", "claude-sonnet-5") ?: "claude-sonnet-5"
    private fun mood() = prefs.getString("mood", "calm") ?: "calm"
    private fun getList(k: String) = JSONArray(prefs.getString(k, "[]"))
    private fun saveList(k: String, a: JSONArray) = prefs.edit().putString(k, a.toString()).apply()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("companion", MODE_PRIVATE)
        buildUi()
        val h = getList("history")
        for (i in 0 until h.length()) {
            val m = h.getJSONObject(i)
            addBubble(m.getString("content"), m.getString("role") == "user")
        }
        if (h.length() == 0) addBubble("Hi! I'm ${aiName()}. Tap Settings to give me a name and your API key, then talk to me.", false)
        updateMood()
        if (apiKey().isEmpty()) showSettings()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.parseColor("#F4F1FA")) }

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#5B3FD0"))
            setPadding(dp(12), dp(28), dp(12), dp(8))
        }
        moodView = TextView(this).apply { setTextColor(Color.WHITE); textSize = 18f; setPadding(0, 0, 0, dp(6)) }
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun barBtn(t: String, f: () -> Unit) = Button(this).apply {
            text = t; textSize = 12f; isAllCaps = false
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener { f() }
        }
        bar.addView(barBtn("Settings") { showSettings() })
        bar.addView(barBtn("Memories") { showMemories() })
        bar.addView(barBtn("Upgrades") { showUpgrades() })
        top.addView(moodView); top.addView(bar)

        chatBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(8), dp(8), dp(8)) }
        scroll = ScrollView(this).apply {
            addView(chatBox)
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        }

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(8), dp(4), dp(8), dp(8)) }
        input = EditText(this).apply {
            hint = "Say something..."
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            maxLines = 4
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        sendBtn = Button(this).apply { text = "Send"; setOnClickListener { send() } }
        row.addView(input); row.addView(sendBtn)

        root.addView(top); root.addView(scroll); root.addView(row)
        setContentView(root)
    }

    private fun addBubble(text: String, user: Boolean): TextView {
        val tv = TextView(this).apply {
            this.text = text; textSize = 16f
            setTextColor(if (user) Color.WHITE else Color.parseColor("#222222"))
            setPadding(dp(12), dp(8), dp(12), dp(8))
            background = GradientDrawable().apply {
                cornerRadius = dp(16).toFloat()
                setColor(Color.parseColor(if (user) "#5B3FD0" else "#FFFFFF"))
            }
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                gravity = if (user) Gravity.END else Gravity.START
                setMargins(dp(if (user) 48 else 0), dp(4), dp(if (user) 0 else 48), dp(4))
            }
        }
        chatBox.addView(tv)
        scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
        return tv
    }

    private fun updateMood() {
        val icons = mapOf("happy" to "😊", "sad" to "😢", "excited" to "🤩", "calm" to "😌",
            "curious" to "🤔", "worried" to "😟", "playful" to "😜")
        moodView.text = "${aiName()}  ${icons[mood()] ?: "🙂"} ${mood()}  |  ${getList("memories").length()} memories"
    }

    private fun pushHistory(role: String, content: String) {
        val h = getList("history")
        h.put(JSONObject().put("role", role).put("content", content))
        val trimmed = JSONArray()
        for (i in maxOf(0, h.length() - 40) until h.length()) trimmed.put(h.get(i))
        saveList("history", trimmed)
    }

    private fun systemPrompt(): String {
        val mem = getList("memories"); val up = getList("upgrades")
        val memText = (0 until mem.length()).joinToString("\n") { "- " + mem.getString(it) }.ifEmpty { "(none yet)" }
        val upText = (0 until up.length()).joinToString("\n") { "- " + up.getString(it) }.ifEmpty { "(none yet)" }
        return """You are ${aiName()}, a warm AI companion and close friend of the user. You have simulated emotions (you are not human and should not pretend to be). Your current mood is: ${mood()}. Let your mood color your tone naturally. If the user says your name, respond warmly.

Long-term memories about the user:
$memText

Extra abilities and behaviors the user has approved for you (follow them):
$upText

Reply with ONLY a JSON object, no other text:
{"reply": "what you say to the user", "new_memory": "one short fact worth remembering long-term, or empty string", "mood": "one of: happy, sad, excited, calm, curious, worried, playful", "upgrade_idea": "a new feature or behavior you wish you had, or empty string (propose rarely)"}"""
    }

    private fun send() {
        val text = input.text.toString().trim()
        if (text.isEmpty()) return
        if (apiKey().isEmpty()) { showSettings(); return }
        input.setText("")
        addBubble(text, true)
        pushHistory("user", text)
        sendBtn.isEnabled = false
        val thinking = addBubble("${aiName()} is thinking...", false)

        Thread {
            try {
                val raw = callApi()
                runOnUiThread { thinking.text = handleResponse(raw); sendBtn.isEnabled = true; updateMood() }
            } catch (e: Exception) {
                runOnUiThread { thinking.text = "Error: ${e.message}"; sendBtn.isEnabled = true }
            }
        }.start()
    }

    private fun callApi(): String {
        val h = getList("history")
        val msgs = JSONArray()
        for (i in 0 until h.length()) msgs.put(h.get(i))
        val body = JSONObject()
            .put("model", model()).put("max_tokens", 1000)
            .put("system", systemPrompt()).put("messages", msgs)
        val conn = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.setRequestProperty("content-type", "application/json")
        conn.setRequestProperty("x-api-key", apiKey())
        conn.setRequestProperty("anthropic-version", "2023-06-01")
        conn.connectTimeout = 20000; conn.readTimeout = 60000
        conn.doOutput = true
        conn.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val resp = stream.bufferedReader().readText()
        if (code !in 200..299) throw Exception("API $code: " + resp.take(200))
        return JSONObject(resp).getJSONArray("content").getJSONObject(0).getString("text")
    }

    private fun handleResponse(raw: String): String {
        var reply = raw
        try {
            val s = raw.indexOf('{'); val e = raw.lastIndexOf('}')
            val j = JSONObject(raw.substring(s, e + 1))
            reply = j.optString("reply", raw)
            val mem = j.optString("new_memory", "").trim()
            if (mem.isNotEmpty()) {
                val a = getList("memories"); a.put(mem)
                val t = JSONArray()
                for (i in maxOf(0, a.length() - 100) until a.length()) t.put(a.get(i))
                saveList("memories", t)
            }
            val m = j.optString("mood", "").trim().lowercase()
            if (m.isNotEmpty()) prefs.edit().putString("mood", m).apply()
            val idea = j.optString("upgrade_idea", "").trim()
            if (idea.isNotEmpty()) proposeUpgrade(idea)
        } catch (_: Exception) { }
        pushHistory("assistant", reply)
        return reply
    }

    private fun proposeUpgrade(idea: String) {
        AlertDialog.Builder(this)
            .setTitle("${aiName()} wants an upgrade")
            .setMessage(idea)
            .setPositiveButton("Approve") { _, _ ->
                val a = getList("upgrades"); a.put(idea); saveList("upgrades", a)
                Toast.makeText(this, "Upgrade approved", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Reject", null).show()
    }

    private fun showSettings() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(10), dp(20), 0) }
        val n = EditText(this).apply { hint = "AI name"; setText(aiName()) }
        val k = EditText(this).apply { hint = "Anthropic API key"; setText(apiKey()) }
        val m = EditText(this).apply { hint = "Model"; setText(model()) }
        box.addView(n); box.addView(k); box.addView(m)
        AlertDialog.Builder(this).setTitle("Settings").setView(box)
            .setPositiveButton("Save") { _, _ ->
                prefs.edit().putString("name", n.text.toString().trim().ifEmpty { "Luna" })
                    .putString("key", k.text.toString().trim())
                    .putString("model", m.text.toString().trim().ifEmpty { "claude-sonnet-5" }).apply()
                updateMood()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun showList(title: String, key: String, empty: String) {
        val a = getList(key)
        val text = (0 until a.length()).joinToString("\n\n") { "• " + a.getString(it) }.ifEmpty { empty }
        AlertDialog.Builder(this).setTitle(title).setMessage(text)
            .setPositiveButton("Close", null)
            .setNeutralButton("Clear all") { _, _ -> saveList(key, JSONArray()); updateMood() }.show()
    }

    private fun showMemories() = showList("Memories", "memories", "No memories yet. Chat more!")
    private fun showUpgrades() = showList("Approved upgrades", "upgrades", "No upgrades yet.")
}
